﻿using Domain;

namespace Application.DTO
{
    public class CommentDto : Entity
    {
        public string Body { get; set; }
        public int UserId { get; set; }
        public int QuoteId { get; set; }
        
    }
}