﻿using Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.DTO
{
    public class RateDto : Entity
    {
        public int Ocena { get; set; }

        public int UserId { get; set; }
        
        public int QuoteId { get; set; }
       
    }
}
