﻿using Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.DTO
{
    public class UserUseCaseDto : Entity
    {
        public int UserId { get; set; }
        public int UseCaseId { get; set; }
    }
}
