﻿using Application.Queries;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Searches
{
    public class RateSearch : PagedSearch
    {
        public int Ocena { get; set; }
        public int QuoteId { get; set; }
        public int UserId { get; set; }
    }
}
