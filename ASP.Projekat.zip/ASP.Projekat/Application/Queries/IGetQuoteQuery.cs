﻿using Application.DTO;
using Application.Searches;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Queries
{
    public interface IGetQuoteQuery : IQuery<QuoteSearch, PagedResponse<QuoteDto>>
    {
    }
}
