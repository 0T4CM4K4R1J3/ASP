﻿using Application;
using Application.Commands;
using Application.DTO;
using Application.Queries;
using Application.Searches;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
  //  [Authorize]
    public class AuthorController : ControllerBase
    {
        private readonly UseCaseExecutor executor;

        public AuthorController(UseCaseExecutor executor)
        {
            this.executor = executor;
        }

        // GET: api/author
        [HttpGet]
        public IActionResult Get(
            [FromQuery] AuthorSearch search,
            [FromServices] IGetAuthorQuery query)
        {
            return Ok(executor.ExecuteQuery(query, search));
        }

        // POST: api/Author
        [HttpPost]
        public IActionResult Post([FromBody] AuthorDto dto,
            [FromServices] ICreateAuthorCommand command)
        {
            executor.ExecuteCommand(command, dto);
            return StatusCode(201);
        }

        // DELETE: api/author/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id, [FromServices] IDeleteAuthorCommand command)
        {
            executor.ExecuteCommand(command, id);
            return NoContent();
        }

        
        // UPDATE: api/author
        [HttpPut]
        public IActionResult Put([FromBody] AuthorDto id, [FromServices] IUpdateAuthorCommand command)
        {
            executor.ExecuteCommand(command, id);
            return StatusCode(200, "Author update successfully");
        }
    }
}
