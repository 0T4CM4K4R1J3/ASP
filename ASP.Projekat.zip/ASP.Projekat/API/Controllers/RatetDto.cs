﻿namespace API.Controllers
{
    public class RatetDto
    {
    }
}