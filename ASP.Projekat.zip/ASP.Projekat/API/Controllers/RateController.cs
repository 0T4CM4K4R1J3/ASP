﻿using Application;
using Application.Commands;
using Application.DTO;
using Application.Queries;
using Application.Searches;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RateController : Controller
    {
        private readonly UseCaseExecutor executor;

        public RateController(UseCaseExecutor executor)
        {
            this.executor = executor;
        }

        // POST: api/rate
        [HttpPost]
        public IActionResult Post([FromBody] RateDto dto,
            [FromServices] ICreateRateCommand command)
        {
            executor.ExecuteCommand(command, dto);
            return StatusCode(201);
        }

        // GET: api/comment
        [HttpGet]
        public IActionResult Get(
            [FromQuery] RateSearch search,
            [FromServices] IGetRateQuery query)
        {
            return Ok(executor.ExecuteQuery(query, search));
        }

        // DELETE: api/rate
        [HttpDelete]
        public IActionResult Delete([FromBody] RateDto id, [FromServices] IDeleteRateCommand command)
        {
            executor.ExecuteCommand(command, id);
            return NoContent();
        }

        // UPDATE: api/rate
        [HttpPut]
        public IActionResult Put([FromBody] RateDto id, [FromServices] IUpdateRateCommand command)
        {
            executor.ExecuteCommand(command, id);
            return StatusCode(200, "Rate updated successfully");

        }
    }
}
