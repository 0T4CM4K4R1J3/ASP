﻿using Application;
using Application.Queries;
using Application.Searches;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogController : Controller
    {
        private readonly UseCaseExecutor executor;

        public LogController(UseCaseExecutor executor)
        {
            this.executor = executor;
        }

        // GET: api/log
        [HttpGet]
        public IActionResult Get(
            [FromQuery] LogSearch search,
            [FromServices] IGetLogsQuery query)
        {
            return Ok(executor.ExecuteQuery(query, search));
        }
    }
}
