﻿using Application;
using Application.Commands;
using Application.DTO;
using Application.Queries;
using Application.Searches;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentController : Controller
    {
        private readonly UseCaseExecutor executor;
        public CommentController(UseCaseExecutor executor)
        {
            this.executor = executor;
        }

        // POST: api/comment
        [HttpPost]
        public IActionResult Post([FromBody] CommentDto dto,
            [FromServices] ICreateCommentCommand command)
        {
            executor.ExecuteCommand(command, dto);
            return StatusCode(201);
        }

        // GET: api/comment
        [HttpGet]
        public IActionResult Get(
            [FromQuery] CommentSearch search,
            [FromServices] IGetCommentQuery query)
        {
            return Ok(executor.ExecuteQuery(query, search));
        }

        // DELETE: api/comment
        [HttpDelete]
        public IActionResult Delete([FromBody] CommentDto id, [FromServices] IDeleteCommentCommand command)
        {
            executor.ExecuteCommand(command, id);
            return NoContent();
        }

        // UPDATE: api/comment
        [HttpPut]
        public IActionResult Put([FromBody] CommentDto id, [FromServices] IUpdateCommentCommand command)
        {
            executor.ExecuteCommand(command, id);
            return StatusCode(200, "Comment update successfully");

        }

    }
}
