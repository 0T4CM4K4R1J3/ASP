﻿using Application;
using Application.Commands;
using Application.DTO;
using Application.Queries;
using Application.Searches;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuoteController : Controller
    {
        private readonly UseCaseExecutor executor;

        public QuoteController(UseCaseExecutor executor)
        {
            this.executor = executor;
        }

        // POST: api/quote
        [HttpPost]
        public IActionResult Post([FromForm] QuoteDto dto,
            [FromServices] ICreateQuoteCommand command)
        {
            executor.ExecuteCommand(command, dto);
            return StatusCode(201, "Quote created successfully");
        }

        // GET: api/quote
        [HttpGet]
        public IActionResult Get(
            [FromQuery] QuoteSearch search,
            [FromServices] IGetQuoteQuery query)
        {
            return Ok(executor.ExecuteQuery(query, search));
        }

        // DELETE: api/quote
        [HttpDelete]
        public IActionResult Delete([FromBody] QuoteDto id, [FromServices] IDeleteQuoteCommand command)
        {
            executor.ExecuteCommand(command, id);
            return StatusCode(204, "Quote Deleted");
        }

        // UPDATE: api/quote
        [HttpPut]
        public IActionResult Put([FromBody] QuoteDto id, [FromServices] IUpdateQuoteCommand command)
        {
            executor.ExecuteCommand(command, id);
            return StatusCode(200, "Quote update successfully");

        }
    }
}
