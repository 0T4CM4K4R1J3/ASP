﻿using Domain;
using EfDataAccess;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly Context _context;

        public TestController(Context context)
        {
            _context = context;
        }

        // POST: api/test
        [HttpPost]
        public void Post()
        {
            var categories = new List<Category>
            {
                new Category
                {
                    Name = "Category 1"
                },
                new Category
                {
                    Name = "Category 2"
                }
            };

            var authors = new List<Author>
            {
                new Author
                {
                    Name = "Author 1"
                },
                new Author
                {
                    Name = "Author 2"
                }
            };

            var users = new List<User>
            {
                new User
                {
                    Username = "admin", Password = "admin", FirstName = "Admin",LastName ="Adminkovic", Email = "m"
                },
                new User
                {
                    Username = "paja", Password = "paja", FirstName = "Paja",LastName ="Patak", Email = "patak"
                },
                new User
                {
                    Username = "panter", Password = "panter", FirstName = "Pink",LastName ="Panter", Email = "aaam"
                }
            };

            var useruc = new List<UserUserCase>
            {
                //admin
                new UserUserCase { User = users.First(), UseCaseId = 10 },
                new UserUserCase { User = users.First(), UseCaseId = 12 },
                new UserUserCase { User = users.First(), UseCaseId = 13 },
                new UserUserCase { User = users.First(), UseCaseId = 14 },
                new UserUserCase { User = users.First(), UseCaseId = 21 },
                new UserUserCase { User = users.First(), UseCaseId = 22 },
                new UserUserCase { User = users.First(), UseCaseId = 23 },
                new UserUserCase { User = users.First(), UseCaseId = 24 },
                new UserUserCase { User = users.First(), UseCaseId = 30 },
                new UserUserCase { User = users.First(), UseCaseId = 31 },
                new UserUserCase { User = users.First(), UseCaseId = 32 },
                new UserUserCase { User = users.First(), UseCaseId = 33 },
                new UserUserCase { User = users.First(), UseCaseId = 40 },
                new UserUserCase { User = users.First(), UseCaseId = 41 },
                new UserUserCase { User = users.First(), UseCaseId = 42 },
                new UserUserCase { User = users.First(), UseCaseId = 43 },
                new UserUserCase { User = users.First(), UseCaseId = 50 },
                new UserUserCase { User = users.First(), UseCaseId = 51 },
                new UserUserCase { User = users.First(), UseCaseId = 52 },
                new UserUserCase { User = users.First(), UseCaseId = 53 },
                new UserUserCase { User = users.First(), UseCaseId = 60 },

                //korisnik
                new UserUserCase { User = users.ElementAt(1), UseCaseId = 30 },
                new UserUserCase { User = users.ElementAt(1), UseCaseId = 31 },
                new UserUserCase { User = users.ElementAt(1), UseCaseId = 32 },
                new UserUserCase { User = users.ElementAt(1), UseCaseId = 33 },
                new UserUserCase { User = users.ElementAt(1), UseCaseId = 40 },
                new UserUserCase { User = users.ElementAt(1), UseCaseId = 41 },
                new UserUserCase { User = users.ElementAt(1), UseCaseId = 50 },
                new UserUserCase { User = users.ElementAt(1), UseCaseId = 51 }
            };

            var quotes = new List<Quote>
            {
                new Quote { User = users.ElementAt(1), Body = "Body 1", Author = authors.ElementAt(1), Category = categories.ElementAt(1), Photo = "slika1" },
                new Quote { User = users.ElementAt(1), Body = "Body 2", Author = authors.ElementAt(1), Category = categories.ElementAt(1), Photo = "slika2" },
                new Quote { User = users.ElementAt(1), Body = "Body 3", Author = authors.ElementAt(1), Category = categories.ElementAt(1), Photo = "slika3" },
                new Quote { User = users.ElementAt(1), Body = "Body 4", Author = authors.ElementAt(1), Category = categories.ElementAt(1), Photo = "slika4" },
                new Quote { User = users.ElementAt(1), Body = "Body 5", Author = authors.ElementAt(1), Category = categories.ElementAt(1), Photo = "slika5" },
                new Quote { User = users.ElementAt(1), Body = "Body 6", Author = authors.ElementAt(1), Category = categories.ElementAt(1), Photo = "slika6" }
            };


            _context.Categories.AddRange(categories);
            _context.Authors.AddRange(authors);
            _context.UserUserCases.AddRange(useruc);
            _context.Quotes.AddRange(quotes);

            _context.SaveChanges();


        }
    }
}
