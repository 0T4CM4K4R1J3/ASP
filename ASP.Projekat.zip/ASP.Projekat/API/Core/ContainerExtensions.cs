﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Application;
using Application.Commands;
using Application.Queries;
using EfDataAccess;
using Implementation.Commands;
using Implementation.Queries;
using Implementation.Validators;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nedelja7.Api.Core;
using Microsoft.OpenApi.Models;

namespace API.Core
{
    public static class ContainerExtensions
    {
        public static void AddUsesCases(this IServiceCollection services)
        {
            services.AddTransient<UseCaseExecutor>();

            services.AddTransient<IRegisterUserCommand, EfRegisterUserCommand>();

            //pregled i search tabele logova
            services.AddTransient<IGetLogsQuery, EfGetLogsQuery>();

            //category crud
            services.AddTransient<IGetCategoryQuery, EfGetCategoryQuery>();
            services.AddTransient<ICreateCategoryCommand, EfCreateCategoryCommand>();
            services.AddTransient<IDeleteCategoryCommand, EfDeleteCategoryCommand>();
            services.AddTransient<IUpdateCategoryCommand, EfUpdateCategoryCommand>(); 

            //author crud
            services.AddTransient<IGetAuthorQuery, EfGetAuthorQuery>();
            services.AddTransient<ICreateAuthorCommand, EfCreateAuthorCommandcs>();
            services.AddTransient<IDeleteAuthorCommand, EfDeleteAuthorCommand>();
            services.AddTransient<IUpdateAuthorCommand, EfUpdateAuthorCommand>();

            //Quote CRUD
            services.AddTransient<ICreateQuoteCommand, EfCreateQuoteCommand>();
            services.AddTransient<IGetQuoteQuery, EfGetQuoteQuery>();
            services.AddTransient<IDeleteQuoteCommand, EfDeleteQuoteCommand>();
            services.AddTransient<IUpdateQuoteCommand, EfUpdateQuoteCommand>();

            //Comment CRUD
            services.AddTransient<ICreateCommentCommand, EfCreateCommentCommand>();
            services.AddTransient<IGetCommentQuery, EfGetQCommentQuery>();
            services.AddTransient<IDeleteCommentCommand, EfDeleteCommentCommand>();
            services.AddTransient<IUpdateCommentCommand, EfUpdateCommentCommand>();

            //Rate
            services.AddTransient<ICreateRateCommand, EfCreateRateCommand>();
            services.AddTransient<IGetRateQuery, EfGetRateQuery>();
            services.AddTransient<IDeleteRateCommand, EfDeleteRateCommand>();
            services.AddTransient<IUpdateRateCommand, EfUpdateRateCommand>();


            //validators
            services.AddTransient<CreateCategoryValidator>();
            services.AddTransient<CreateAuthorValidator>();
            services.AddTransient<RegisterUserValidator>();
            services.AddTransient<CreateQuoteValidator>();
            services.AddTransient<CreateCommentValidator>();
            services.AddTransient<CreateRateValidator>();

        }

        public static void AddSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "ASP Mladen Nikolic", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = @"JWT Authorization header using the Bearer scheme. \r\n\r\n 
                      Enter 'Bearer' [space] and then your token in the text input below.
                      \r\n\r\nExample: 'Bearer 12345abcdef'",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                        new OpenApiSecurityScheme
                          {
                            Reference = new OpenApiReference
                              {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                              },
                              Scheme = "oauth2",
                              Name = "Bearer",
                              In = ParameterLocation.Header,

                            },
                            new List<string>()
                          }
                    });
            });
        }

        public static void AddApplicationActor(this IServiceCollection services)
        {
            services.AddTransient<IApplicationActor>(x =>
            {
                var accessor = x.GetService<IHttpContextAccessor>();
                var user = accessor.HttpContext.User;

                if (user.FindFirst("ActorData") == null)
                {
                    return new UnauthorisedActor();
                }

                var actorString = user.FindFirst("ActorData").Value;

                var actor = Newtonsoft.Json.JsonConvert.DeserializeObject<JwtActor>(actorString);

                return actor;
            });
            }

        public static void AddJwt(this IServiceCollection services)
        {
            services.AddTransient<JwtManager>();

            services.AddAuthentication(options =>
            {
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultSignInScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(cfg =>
            {
                cfg.RequireHttpsMetadata = false;
                cfg.SaveToken = true;
                cfg.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = "asp_api",
                    ValidateIssuer = true,
                    ValidAudience = "Any",
                    ValidateAudience = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("ThisIsMyVerySecretKey")),
                    ValidateIssuerSigningKey = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                };
            });
        }
    }
}
