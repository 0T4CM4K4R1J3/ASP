using Application.Commands;
using EfDataAccess;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Implementation.Commands;
using API.Core;
using Application;
using Implementation.Validators;
using Implementation.Queries;
using Application.Queries;
using Implementation.Logging;
using Nedelja7.Api.Core;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Http;
using Implementation.Email;
using Application.Email;
using AutoMapper;
using Microsoft.OpenApi.Models;

namespace API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<Context>();
            services.AddUsesCases();
            services.AddHttpContextAccessor();
            services.AddApplicationActor();
            services.AddJwt();

            //services.AddTransient<IUseCaseLogger, ConsoleUseCaseLogger>();
            services.AddTransient<IUseCaseLogger, DatabaseUseCaseLogger>();

            services.AddTransient<IEmailSender, SmtpEmailSender>();

            services.AddAutoMapper(typeof(EfGetCategoryQuery).Assembly);
            services.AddAutoMapper(typeof(EfGetAuthorQuery).Assembly);
            services.AddControllers();

            services.AddSwagger();

            
        }


        // This method gets called by the runtime. Use this method to configure the HTTP req uest pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Swagger");
            });
            app.UseRouting();
            app.UseStaticFiles();
            app.UseMiddleware<GlobalExceptionHandler>();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
