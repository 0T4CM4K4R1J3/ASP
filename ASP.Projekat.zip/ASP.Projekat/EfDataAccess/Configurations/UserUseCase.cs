﻿namespace EfDataAccess.Configurations
{
    public class UserUseCase
    {
    }
}