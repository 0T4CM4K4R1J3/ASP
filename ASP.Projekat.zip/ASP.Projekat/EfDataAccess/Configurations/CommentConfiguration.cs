﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EfDataAccess.Configurations
{
    public class CommentConfiguration : IEntityTypeConfiguration<Comment>
    {
        public void Configure(EntityTypeBuilder<Comment> builder)
        {
            builder.Property(x => x.Body).IsRequired();
            builder.HasIndex(x => x.Body);

            builder.HasOne(x => x.Quote).WithMany(x => x.Comments).OnDelete(DeleteBehavior.Restrict);
        }
    }
}
