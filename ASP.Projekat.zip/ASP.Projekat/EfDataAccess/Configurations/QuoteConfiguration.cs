﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EfDataAccess.Configurations
{
   public  class QuoteConfiguration : IEntityTypeConfiguration<Quote>
    {
        public void Configure(EntityTypeBuilder<Quote> builder)
        {
            builder.Property(x => x.Body).IsRequired();
            builder.HasIndex(x => x.Body);

            builder.HasMany(x => x.Comments)
                   .WithOne(y => y.Quote)
                   .HasForeignKey(x => x.QuoteId).OnDelete(DeleteBehavior.Cascade);

        }
    }
}
