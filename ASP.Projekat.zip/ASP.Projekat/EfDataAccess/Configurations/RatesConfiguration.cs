﻿using Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace EfDataAccess.Configurations
{
    public class RatesConfiguration : IEntityTypeConfiguration<Rate>
    {
        public void Configure(EntityTypeBuilder<Rate> builder)
        {
            builder.Property(x => x.Ocena).IsRequired();
            builder.HasIndex(x => x.Ocena);

            builder.HasOne(x => x.User).WithMany(x => x.Rates).OnDelete(DeleteBehavior.NoAction);
        }
    }
}
