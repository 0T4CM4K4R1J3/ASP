﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EfDataAccess.Migrations
{
    public partial class Alter2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "UseCaseName",
                table: "UseCaseLogs",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Actor",
                table: "UseCaseLogs",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Photo",
                table: "Quotes",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_UseCaseLogs_Actor",
                table: "UseCaseLogs",
                column: "Actor");

            migrationBuilder.CreateIndex(
                name: "IX_UseCaseLogs_Date",
                table: "UseCaseLogs",
                column: "Date");

            migrationBuilder.CreateIndex(
                name: "IX_UseCaseLogs_UseCaseName",
                table: "UseCaseLogs",
                column: "UseCaseName");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_UseCaseLogs_Actor",
                table: "UseCaseLogs");

            migrationBuilder.DropIndex(
                name: "IX_UseCaseLogs_Date",
                table: "UseCaseLogs");

            migrationBuilder.DropIndex(
                name: "IX_UseCaseLogs_UseCaseName",
                table: "UseCaseLogs");

            migrationBuilder.DropColumn(
                name: "Photo",
                table: "Quotes");

            migrationBuilder.AlterColumn<string>(
                name: "UseCaseName",
                table: "UseCaseLogs",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Actor",
                table: "UseCaseLogs",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);
        }
    }
}
