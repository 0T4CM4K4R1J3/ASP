﻿using System.Collections.Generic;

namespace Domain
{
    public class Quote : Entity
    {
        
        public int UserId { get; set; }
        public User User { get; set; }
        public string Body { get; set; }
        public int AuthorId { get; set; }
        public Author Author { get; set; }
        public int CategoryId { get; set; }
        public Category Category { get; set; }
        public string Photo { get; set; }   

        public virtual ICollection<Rate> Rates { get; set; } = new HashSet<Rate>();
        public virtual ICollection<Comment> Comments { get; set; } = new HashSet<Comment>();
    }
}