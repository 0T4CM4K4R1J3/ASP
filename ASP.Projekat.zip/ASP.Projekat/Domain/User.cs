﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Domain
{
    public class User : Entity
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Email { get; set; }

        public virtual ICollection<Quote> Quotes { get; set; } = new HashSet<Quote>();

        public virtual ICollection<UserUserCase> UserUserCases { get; set; } = new HashSet<UserUserCase>();

        public virtual ICollection<Rate> Rates{ get; set; } = new HashSet<Rate>();
        public virtual ICollection<Comment> Comments { get; set; } = new HashSet<Comment>();
    }
}
