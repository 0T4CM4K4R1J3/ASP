﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace Domain
{
    public class Rate : Entity
    {
        [Required]
        public int Ocena { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
        public int QuoteId { get; set; }
        public Quote Quote { get; set; }

    }
}
