﻿using Application.DTO;
using Application.Queries;
using Application.Searches;
using AutoMapper;
using Domain;
using EfDataAccess;
using Implementation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Implementation.Queries
{
    public class EfGetQCommentQuery : IGetCommentQuery
    {
        private readonly Context context;
        private readonly IMapper _mapper;

        public EfGetQCommentQuery(Context context, IMapper mapper)
        {
            this.context = context;
            _mapper = mapper;
        }

        public int Id => 41;

        public string Name => "Comment get";

        public PagedResponse<CommentDto> Execute(CommentSearch search)
        {
            var query = context.Comments.AsQueryable();

            if (!string.IsNullOrEmpty(search.Body) || !string.IsNullOrWhiteSpace(search.Body))
            {
                query = query.Where(x => x.Body.ToLower().Contains(search.Body.ToLower()));
            }

            return query.Paged<CommentDto, Comment>(search, _mapper);
        }
    }
}
