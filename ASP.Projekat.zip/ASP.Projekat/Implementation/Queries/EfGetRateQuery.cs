﻿using Application.DTO;
using Application.Queries;
using Application.Searches;
using AutoMapper;
using Domain;
using EfDataAccess;
using Implementation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Implementation.Queries
{
    public class EfGetRateQuery : IGetRateQuery
    {
        private readonly Context context;
        private readonly IMapper _mapper;

        public EfGetRateQuery(Context context, IMapper mapper)
        {
            this.context = context;
            _mapper = mapper;
        }

        public int Id => 51;

        public string Name => "Get and search Rates";

        public PagedResponse<RateDto> Execute(RateSearch search)
        {
            var query = context.Rates.AsQueryable();

            var ocena = search.Ocena;

            if (ocena > 0)
            {
                query = query.Where(x => x.Ocena.Equals(search.Ocena));
            }

            var userId = search.UserId; 
            if (userId > 0)
            {
                query = query.Where(x => x.UserId.Equals(search.UserId));
            }

            var quoteId = search.QuoteId;
            if (quoteId > 0)
            {
                query = query.Where(x => x.QuoteId.Equals(search.QuoteId));
            }

            return query.Paged<RateDto, Rate>(search, _mapper);
        }
    }
}
