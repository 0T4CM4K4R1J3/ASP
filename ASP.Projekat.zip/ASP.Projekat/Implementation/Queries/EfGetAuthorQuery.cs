﻿using Application.DTO;
using Application.Queries;
using Application.Searches;
using AutoMapper;
using Domain;
using EfDataAccess;
using Implementation.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Implementation.Queries
{
    public class EfGetAuthorQuery : IGetAuthorQuery
    {
        private readonly Context context;
        private readonly IMapper _mapper;

        public EfGetAuthorQuery(Context context, IMapper mapper)
        {
            this.context = context;
            _mapper = mapper;
        }
        public int Id => 21;

        public string Name => "Author search.";

        
        public PagedResponse<AuthorDto> Execute(AuthorSearch search)
        {
            var query = context.Authors.AsQueryable();

            if (!string.IsNullOrEmpty(search.Name) || !string.IsNullOrWhiteSpace(search.Name))
            {
                query = query.Where(x => x.Name.ToLower().Contains(search.Name.ToLower()));
            }

            return query.Paged<AuthorDto, Author>(search, _mapper);
        }
    }
}
