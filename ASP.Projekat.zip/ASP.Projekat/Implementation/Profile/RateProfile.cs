﻿using Application.DTO;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Profiles
{
   public class RateProfile : Profile
    {
        public RateProfile()
        {
            CreateMap<Domain.Rate, RateDto>();
        }
    }
}
