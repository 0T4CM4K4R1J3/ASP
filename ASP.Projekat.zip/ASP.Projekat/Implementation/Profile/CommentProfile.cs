﻿using Application.DTO;
using Domain;
using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;

namespace Implementation.Profiles
{
    public class CommentProfile : Profile
    {
        public CommentProfile()
        {
            CreateMap<Comment, CommentDto>();
        }
    }
}
