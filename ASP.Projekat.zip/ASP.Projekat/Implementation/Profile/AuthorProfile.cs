﻿using AutoMapper;
using Application.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Profiles
{
    public class AuthorProfile : Profile
    {
        public AuthorProfile()
        {
            CreateMap<Domain.Author, AuthorDto>();
        }
    }
}
