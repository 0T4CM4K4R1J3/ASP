﻿using System;
using System.Collections.Generic;
using System.Text;
using Application.DTO;
using Application.Commands;
using EfDataAccess;
using Application.Exceptions;
using Domain;

namespace Implementation.Commands
{
    public class EfDeleteCategoryCommand : IDeleteCategoryCommand
    {
        private readonly Context _context;

        public EfDeleteCategoryCommand(Context context)
        {
            _context = context;
        }

        public int Id => 11;

        public string Name => "Delete category";

        public void Execute(CategoryDto id)
        {
            var category = _context.Categories.Find(id.Id);

            if (category == null)
            {
                throw new EntityNotFoundException(id.Id, typeof(Category));
            }

            _context.Categories.Remove(category);

            _context.SaveChanges();
        }
    }
}
