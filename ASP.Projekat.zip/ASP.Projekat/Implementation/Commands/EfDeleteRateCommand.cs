﻿using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using Domain;
using EfDataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfDeleteRateCommand : IDeleteRateCommand
    {
        private readonly Context _context;

        public EfDeleteRateCommand(Context context)
        {
            _context = context;
        }

        public int Id => 52;

        public string Name => "Delete Rate ";

        public void Execute(RateDto request)
        {
            var rate = _context.Rates.Find(request.Id);

            if (rate == null)
            {
                throw new EntityNotFoundException(request.Id, typeof(Rate));
            }

            _context.Rates.Remove(rate);

            _context.SaveChanges();
        }
    }
}
