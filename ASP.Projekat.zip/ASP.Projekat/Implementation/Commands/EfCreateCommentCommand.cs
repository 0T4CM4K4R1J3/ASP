﻿using Application.Commands;
using Application.DTO;
using Domain;
using EfDataAccess;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfCreateCommentCommand : ICreateCommentCommand
    {
        private readonly Context _context;
        private readonly CreateCommentValidator _validator;

        public EfCreateCommentCommand(Context context, CreateCommentValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        public int Id => 40;

        public string Name => "Add comment to quote";

        public void Execute(CommentDto request)
        {
            _validator.ValidateAndThrow(request);

            var comm = new Comment
            {
                Body = request.Body,
                UserId = request.UserId,
                QuoteId = request.QuoteId
            };

            _context.Add(comm);
            _context.SaveChanges();
        }
    }
}
