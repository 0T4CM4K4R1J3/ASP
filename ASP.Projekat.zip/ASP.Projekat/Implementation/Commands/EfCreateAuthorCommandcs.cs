﻿using Application.Commands;
using Application.DTO;
using Domain;
using EfDataAccess;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfCreateAuthorCommandcs : ICreateAuthorCommand
    {
        private readonly Context _context;
        private readonly CreateAuthorValidator _validator;

        public EfCreateAuthorCommandcs(Context context, CreateAuthorValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        public int Id => 22;

        public string Name => "Create new Author";

        public void Execute(AuthorDto request)
        {
            _validator.ValidateAndThrow(request);

            var author = new Author
            {
                Name = request.Name
            };

            _context.Add(author);
            _context.SaveChanges();
        }
    }
}
