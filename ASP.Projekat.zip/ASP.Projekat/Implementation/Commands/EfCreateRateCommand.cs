﻿using Application.Commands;
using Application.DTO;
using Domain;
using EfDataAccess;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfCreateRateCommand : ICreateRateCommand
    {
        private readonly Context _context;
        private readonly CreateRateValidator _validator;

        public EfCreateRateCommand(Context context, CreateRateValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        public int Id => 50;

        public string Name => "Create Rate for quote";

        public void Execute(RateDto request)
        {
            _validator.ValidateAndThrow(request);

            var rate = new Rate
            {
                Ocena = request.Ocena,
                UserId = request.UserId,
                QuoteId = request.QuoteId
            };

            _context.Add(rate);
            _context.SaveChanges();
        }
    }
}
