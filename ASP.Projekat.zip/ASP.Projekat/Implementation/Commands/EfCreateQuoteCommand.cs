﻿using Application.Commands;
using Application.DTO;
using Domain;
using EfDataAccess;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;


namespace Implementation.Commands
{
    public class EfCreateQuoteCommand : ICreateQuoteCommand
    {
        private readonly Context _context;
        private readonly CreateQuoteValidator _validator;

        public EfCreateQuoteCommand(Context context, CreateQuoteValidator validator)
        {
            _context = context;
            _validator = validator;
        }


        public int Id => 30;
        public string Name => "Create new Quote";

        public void Execute(Application.DTO.QuoteDto request)
        {
            _validator.ValidateAndThrow(request);

            var guid = Guid.NewGuid();
            var extension = Path.GetExtension(request.Image.FileName);

            var newFileName = guid + extension;

            var path = Path.Combine("wwwroot", "images", newFileName);

            using (var fileStream = new FileStream(path, FileMode.Create))
            {
                request.Image.CopyTo(fileStream);
            }

            ///newFileName poslati u bazu

            var quote = new Quote
            {
                Body = request.Body,
                UserId = request.UserId,
                AuthorId = request.AuthorId,
                CategoryId = request.CategoryId,
                 Photo = newFileName
            };

            _context.Add(quote);
            _context.SaveChanges();
        }
    }
}
