﻿using Application.Commands;
using Application.Exceptions;
using EfDataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfDeleteAuthorCommand : IDeleteAuthorCommand
    {
        private readonly Context _context;

        public EfDeleteAuthorCommand(Context context)
        {
            _context = context;
        }

        public int Id => 23;

        public string Name => "Delete Author";

        public void Execute(int id)
        {
            var author = _context.Authors.Find(id);

            if (author == null)
            {
                throw new EntityNotFoundException(id, typeof(Domain.Author));
            }

            _context.Authors.Remove(author);

            _context.SaveChanges();
        }
    }
}
