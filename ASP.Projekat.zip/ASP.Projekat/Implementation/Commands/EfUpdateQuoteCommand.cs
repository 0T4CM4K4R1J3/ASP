﻿using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using Domain;
using EfDataAccess;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfUpdateQuoteCommand : IUpdateQuoteCommand
    {
        private readonly Context _context;
        private readonly CreateQuoteValidator _validator;

        public EfUpdateQuoteCommand(CreateQuoteValidator validator, Context context)
        {
            _validator = validator;
            _context = context;
        }

        public int Id => 33;

        public string Name => "Update Quote";

        public void Execute(QuoteDto request)
        {
            _validator.ValidateAndThrow(request);

            var quote = _context.Quotes.Find(request.Id);

            if (quote == null)
            {
                throw new EntityNotFoundException(request.Id, typeof(Quote));
            }

            quote.Body = request.Body;
            quote.UserId = request.UserId;
            quote.AuthorId = request.AuthorId;
            quote.CategoryId = request.CategoryId;
            _context.Quotes.Update(quote);
            _context.SaveChanges();
        }
    }
}
