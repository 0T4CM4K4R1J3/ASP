﻿using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using Domain;
using EfDataAccess;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfUpdateRateCommand : IUpdateRateCommand
    {
        private readonly Context _context;
        private readonly CreateRateValidator _validator;

        public EfUpdateRateCommand(Context context, CreateRateValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        public int Id => 53;

        public string Name => "Edit rate";

        public void Execute(RateDto request)
        {
            _validator.ValidateAndThrow(request);

            var rate = _context.Rates.Find(request.Id);

            if (rate == null)
            {
                throw new EntityNotFoundException(request.Id, typeof(Rate));
            }

            rate.Ocena = request.Ocena;
            rate.UserId = request.UserId;
            rate.QuoteId = request.QuoteId;
            _context.Rates.Update(rate);
            _context.SaveChanges();
        }
    }
}
