﻿using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using Domain;
using EfDataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfDeleteQuoteCommand : IDeleteQuoteCommand
    {
        private readonly Context _context;

        public EfDeleteQuoteCommand(Context context)
        {
            _context = context;
        }

        public int Id => 32;

        public string Name => "Delete Quote";

        public void Execute(QuoteDto request)
        {
            var quote = _context.Quotes.Find(request.Id);

            if (quote == null)
            {
                throw new EntityNotFoundException(request.Id, typeof(Quote));
            }

            _context.Quotes.Remove(quote);

            _context.SaveChanges();
        }
    }
}
