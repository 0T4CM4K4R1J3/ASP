﻿using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using Domain;
using EfDataAccess;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfUpdateCommentCommand : IUpdateCommentCommand
    {
        private readonly Context _context;
        private readonly CreateCommentValidator _validator;

        public EfUpdateCommentCommand(Context context, CreateCommentValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        public int Id => 43;

        public string Name => "Edit Comment";

        public void Execute(CommentDto request)
        {
            _validator.ValidateAndThrow(request);

            var comment = _context.Comments.Find(request.Id);

            if (comment == null)
            {
                throw new EntityNotFoundException(request.Id, typeof(Comment));
            }

            comment.Body = request.Body;
            comment.UserId = request.UserId;
            comment.QuoteId = request.QuoteId;
            _context.Comments.Update(comment);
            _context.SaveChanges();
        }
    }
}
