﻿using Application.Commands;
using Application.DTO;
using Application.Exceptions;
using Domain;
using EfDataAccess;
using FluentValidation;
using Implementation.Validators;
using System;
using System.Collections.Generic;
using System.Text;

namespace Implementation.Commands
{
    public class EfUpdateAuthorCommand : IUpdateAuthorCommand
    {
        private readonly Context _context;
        private readonly CreateAuthorValidator _validator;

        public EfUpdateAuthorCommand(Context context, CreateAuthorValidator validator)
        {
            _context = context;
            _validator = validator;
        }

        public int Id => 24;

        public string Name => "Update Author";

        public void Execute(AuthorDto request)
        {
            _validator.ValidateAndThrow(request);

            var author = _context.Authors.Find(request.Id);

            if (author == null)
            {
                throw new EntityNotFoundException(request.Id, typeof(Author));
            }

            author.Name = request.Name;
            _context.Authors.Update(author);
            _context.SaveChanges();
        }
    }
}
