﻿using Application.DTO;
using EfDataAccess;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Implementation.Validators
{
  public  class CreateQuoteValidator : AbstractValidator<QuoteDto>
    {
        public CreateQuoteValidator(Context context)
        {
            RuleFor(x => x.Body)
                .NotEmpty()
                .WithMessage("Text body is required")
                .Must(body => !context.Quotes.Any(q => q.Body == body))
                .WithMessage("That quote already exist");

            RuleFor(x => x.AuthorId).Must(x => context.Authors.Any(y => y.Id == x)).WithMessage("Author doesn't exist");
            RuleFor(x => x.UserId).Must(x => context.Users.Any(y => y.Id == x)).WithMessage("User doesn't exist");
            RuleFor(x => x.CategoryId).Must(x => context.Categories.Any(y => y.Id == x)).WithMessage("Category doesn't exist");
        }
    }
}
