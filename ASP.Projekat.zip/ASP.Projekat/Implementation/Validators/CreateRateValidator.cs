﻿using Application.DTO;
using EfDataAccess;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Implementation.Validators
{
    public class CreateRateValidator : AbstractValidator<RateDto>
    {
        public CreateRateValidator(Context context)
        {
            RuleFor(x => x.Ocena)
                .NotEmpty().WithMessage("Rate body is required")
                .GreaterThan(0).WithMessage("Rate must be in 1-10 interval")
                .LessThanOrEqualTo(10).WithMessage("Rate must be in 1-10 interval");                ;
            RuleFor(x => x.UserId).Must(x => context.Users.Any(y => y.Id == x)).WithMessage("User doesn't exist");
            RuleFor(x => x.QuoteId).Must(x => context.Quotes.Any(y => y.Id == x)).WithMessage("Quote doesn't exist");
        }
    }
}
