﻿using Application.DTO;
using EfDataAccess;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Implementation.Validators
{
    public class CreateCommentValidator : AbstractValidator<CommentDto>
    {
        public CreateCommentValidator(Context context)
        {
            RuleFor(x => x.Body)
                .NotEmpty()
                .WithMessage("Comment text body is required");

            RuleFor(x => x.UserId).Must(x => context.Users.Any(y => y.Id == x)).WithMessage("User doesn't exist");
            RuleFor(x => x.QuoteId).Must(x => context.Quotes.Any(y => y.Id == x)).WithMessage("Quote doesn't exist");
        }
    }
}
